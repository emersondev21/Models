
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
    }

    h1 {
      color: #333;
      text-align: center;
    }

    #btnObterLocalizacao {
      display: block;
      margin: 20px auto;
      padding: 10px 20px;
      font-size: 18px;
      background-color: #337ab7;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    #coordenadas {
      font-weight: bold;
      margin-bottom: 20px;
    }

    #localizacoes {
      margin-top: 20px;
    }

    #localizacoes p {
      margin-bottom: 10px;
    }

    #localizacoes p:last-child {
      margin-bottom: 0;
    }
