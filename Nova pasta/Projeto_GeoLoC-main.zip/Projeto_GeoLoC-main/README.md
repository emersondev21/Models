# Projeto_GeoLoC
Este repositório contem o projeto de rastreio de ônibus da UABJ.
